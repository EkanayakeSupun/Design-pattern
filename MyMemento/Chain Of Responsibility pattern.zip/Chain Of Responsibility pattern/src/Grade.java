public enum Grade {
    A,B,C,S,F
}
